function Get-UnattendedContent
{
	param ()
	
	return $script:un
}