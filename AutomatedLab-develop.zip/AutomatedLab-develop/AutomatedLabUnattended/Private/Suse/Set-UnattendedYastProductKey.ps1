function Set-UnattendedYastProductKey
{
	param (
		[Parameter(Mandatory = $true)]
		[string]$ProductKey
    )
}