function Add-UnattendedYastSynchronousCommand
{
    param (
        [Parameter(Mandatory)]
        [string]$Command,
		
        [Parameter(Mandatory)]
        [string]$Description
    )

}