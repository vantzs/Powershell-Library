function Add-UnattendedYastRenameNetworkAdapters
{

}